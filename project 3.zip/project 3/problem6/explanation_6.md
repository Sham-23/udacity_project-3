---
## Problem #6: Max and Min in a Unsorted Array

### Design
First things first, if the list size is zero just return False. If the list size is one then set min and max to the lone value. Use the first two items in the list and comparing them, set them to min or max. These form the base values for comparing items in the rest of the list. Now walk through the remainder of the list and compare items to update min or max as needed.

### Big O Space Complexity
Two variables to hold min and max plus a copy of the list of n elements: O(n)

### Big O Time Complexity
Makes one pass through the list examining each element one time: O(n) with n being number of elements in list.
