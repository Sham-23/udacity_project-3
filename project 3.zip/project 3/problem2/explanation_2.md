---

#### Problem 2 - Rotated Array Search
First we traverse through the rotated sorted array to find the "middle" index
where the array was rotated. We use that found index to determine which half of
the array to start our pivot search. From here, we simply increment up or down
until we find the matching number. If at any point our pivot is at 0, equal to the
index, or larger than the list, we haven't found the number and we return -1.

The space complexity is O(1) because we only create placeholder variables with
no extra collections to perform our logic.


### Big O Time Complexity
Finding the pivot point is similar to a binary search as both begin by halving the list through each iteration and continuing  dividing it in half until we find the pivot point or the target value. Both should operate in O(log n), where n is the input size of the array/list. If the target value is found in the first, middle or last position within the list then it operates at O(1) best case. 

